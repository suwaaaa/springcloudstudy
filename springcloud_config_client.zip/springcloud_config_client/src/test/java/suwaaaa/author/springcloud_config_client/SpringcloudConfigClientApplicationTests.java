package suwaaaa.author.springcloud_config_client;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringcloudConfigClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
