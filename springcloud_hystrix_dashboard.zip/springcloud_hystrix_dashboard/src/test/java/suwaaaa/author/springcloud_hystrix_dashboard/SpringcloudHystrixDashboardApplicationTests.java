package suwaaaa.author.springcloud_hystrix_dashboard;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringcloudHystrixDashboardApplicationTests {

	@Test
	void contextLoads() {
	}

}
